1. 先进入build文件夹，执行 cmake .. 命令
2. 编译文件，键入 make
3. 可执行文件会生成在bin目录中
